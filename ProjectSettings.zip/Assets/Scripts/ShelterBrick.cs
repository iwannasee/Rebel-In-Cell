﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShelterBrick : MonoBehaviour {
	public int maxHit;

	private int timesHit;
	// Use this for initialization
	void Start () {
		timesHit = 0;	
	}
	
	// Update is called once per frame
	void Update () {
		if (timesHit >= maxHit) {
			Destroy (gameObject);
		}
	}

	void OnCollisionEnter2D(Collision2D collision){
		if (collision.gameObject.CompareTag ("Projectile Ball")) {
			timesHit++;
		}
	}
}
