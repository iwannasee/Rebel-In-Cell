﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileBall : MonoBehaviour {
	public float startForce;
	public float speedTweakNumber;
	private Rigidbody2D rg2D;
	void Start () {
		rg2D = this.GetComponent<Rigidbody2D>() ;
		rg2D.velocity = new Vector2 (0f, transform.position.y + startForce);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter2D(Collision2D collision){
		if (collision.gameObject.CompareTag ("Player")) {
			SpeedTweaking ();
		}
	}

	void SpeedTweaking(){
		Vector2 tweak = new Vector2 (Random.Range (-speedTweakNumber, speedTweakNumber), Random.Range (-speedTweakNumber, speedTweakNumber));
		rg2D.velocity += tweak;
	}
}
