﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PaddleShield : MonoBehaviour {
	public float moveSpeed;
	public bool isPlayWithMouse;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (isPlayWithMouse) {
			PlayWithMouse ();
		}
	}

	void PlayWithArrow(){
		Vector3 newPos = new Vector3 (transform.position.x + Input.GetAxis ("Horizontal") * moveSpeed * Time.deltaTime, transform.position.y, 0);
		this.transform.position = newPos;
	}

	void PlayWithMouse(){
		float MousePos = Input.mousePosition.x / Screen.width*10f;
		Vector3 paddleShieldPos = new Vector3 (Mathf.Clamp (MousePos, -2.65f, 2.65f), this.transform.position.y, 0f);
		this.transform.position = paddleShieldPos;
	}
}
